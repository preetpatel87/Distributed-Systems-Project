package com.apress.kubdev.news.core;

public interface GeoSearchService {
	public GeoSearchResult search(String name);
}
