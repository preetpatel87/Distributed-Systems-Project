export class Settings {
    apiUrl: string;   
}